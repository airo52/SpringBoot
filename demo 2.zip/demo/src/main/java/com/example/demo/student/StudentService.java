package com.example.demo.student;



import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;

@Component
public class StudentService {


    public List <Student> getStudents(){
        return Arrays.asList(
                new Student(
                        1L,
                        "Airo",
                        LocalDate.of(2000, Month.AUGUST,10),
                        24,
                        "airotony8@gmail.com"
                )
        );
    }

}
